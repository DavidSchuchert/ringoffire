# playing_cards
Images of a four-color deck / playing cards that can be used to implement your own card game

The whole card deck is downloaded from the following URL: I just cutted it into the right pieces and named them right. May i'll help someone with my work. ;-)
https://pixabay.com/de/vectors/kartenspiel-deck-karten-spielkarten-161536/
